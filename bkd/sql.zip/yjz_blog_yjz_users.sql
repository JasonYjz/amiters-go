create table yjz_users
(
    id        int unsigned not null comment '用户唯一ID'
        primary key,
    name      varchar(50)  null comment '用户名称',
    mail      varchar(50)  null comment '邮箱',
    wxid      varchar(12)  null comment '微信ID',
    img       varchar(32)  null comment '头像',
    qq        varchar(12)  null comment 'qq号',
    signature varchar(100) null comment '个性签名'
);

