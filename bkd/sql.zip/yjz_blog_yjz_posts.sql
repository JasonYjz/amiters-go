create table yjz_posts
(
    id                   int unsigned           not null comment '文章唯一ID'
        primary key,
    user_id              int unsigned           not null comment '用户id',
    section_id           int unsigned           null comment '文章分类的id',
    title                varchar(50)            not null comment '文章标题',
    content              mediumtext             not null comment '文章内容',
    view_count           int unsigned default 0 not null comment '浏览量',
    liked_count          int unsigned default 0 not null comment '点赞数',
    create_time          datetime               null comment '创建时间',
    update_time          datetime               null comment '更新时间',
    lastest_comment_time datetime               null comment '最近评论时间',
    constraint yjz_posts_yjz_section_id_fk
        foreign key (section_id) references yjz_section (id),
    constraint yjz_posts_yjz_users_id_fk
        foreign key (user_id) references yjz_users (id)
);

