create table yjz_section
(
    id          int unsigned not null comment '文章分类的唯一ID'
        primary key,
    name        varchar(50)  null comment '分类的名称',
    description varchar(100) null comment '某个分类的描述'
);

