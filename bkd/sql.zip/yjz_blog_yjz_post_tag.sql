create table yjz_post_tag
(
    post_id int unsigned null comment '文章id',
    tag_id  int unsigned null,
    constraint yjz_post_tag_yjz_posts_id_fk
        foreign key (post_id) references yjz_posts (id),
    constraint yjz_post_tag_yjz_tags_id_fk
        foreign key (tag_id) references yjz_tags (id)
);

