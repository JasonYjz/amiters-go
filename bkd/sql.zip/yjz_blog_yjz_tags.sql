create table yjz_tags
(
    id   int unsigned not null comment '标签唯一id'
        primary key,
    name varchar(20)  null comment '标签名称'
);

